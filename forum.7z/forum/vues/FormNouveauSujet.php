
    <section id="hero" class="clearfix">    
  
    <div class="conteneur">
       <div class="row"> 
        <div class="grid_5">
			<form method='POST' action='index.php'>
				<label for='titre'> Titre:</label>
				<input type='text' name='titre' id='titre'><br>
				<label for='texte'>Texte:</label>
				<textarea  rows="15" cols="40" name='texte' id='texte'></textarea><br>
				
				<input type='hidden' name='action' value='InsertSujet'>
				<input type='submit' name='submit' value='Submit'>
				</form>
            
        </div>
        <div class="grid_7 rightfloat">
              <div>
                    <img src="images/basic-pic1.jpg" />
                          <p></p>
                     
                </div>
         </div><!-- fin grid_7 -->
        </div><!-- fin row -->
       </div><!-- fin conteneur -->
    </section><!-- fin zone hero  -->
