        <h1>Affichage d'un seul film</h1>
        Titre : <?= $data["film"]->titre ?><br>
        Description : <?= $data["film"]->description ?><br>