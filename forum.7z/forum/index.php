<?php
    require_once("config.php");
    Routeur::route();

?>